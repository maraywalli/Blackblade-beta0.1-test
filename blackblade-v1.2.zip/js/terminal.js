
document.getElementById('terminal-input').addEventListener('keydown', function(event) {
    if (event.key === 'Enter') {
        event.preventDefault();
        let cmd = this.value.trim();
        this.value = '';
        fetch('https://api.yourmodel.com/simulate', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
                'Authorization': 'Bearer YOUR_API_KEY'
            },
            body: JSON.stringify({ prompt: "Act as Kali Linux terminal. Command: " + cmd })
        })
        .then(res => res.json())
        .then(data => {
            document.getElementById('terminal-output').innerText += "\n" + data.response;
        })
        .catch(() => {
            document.getElementById('terminal-output').innerText += "\n[Error executing command]";
        });
    }
});
