
window.onload = () => {
    setTimeout(() => {
        document.getElementById('boot-screen').style.display = 'none';
        document.getElementById('login-screen').style.display = 'flex';
    }, 2000);
};

function login() {
    let user = document.getElementById('username').value;
    let pass = document.getElementById('password').value;
    if (user === 'root' && pass === 'toor') {
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('desktop').style.display = 'block';
    } else {
        alert('Wrong credentials');
    }
}
