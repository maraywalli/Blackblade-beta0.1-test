
window.onload = () => {
    document.getElementById('username').focus();
    updateClock();
    setInterval(updateClock, 1000);
    if (localStorage.getItem('blackbladeUser')) autoLogin();
};

function updateClock() {
    const clock = document.getElementById('clock');
    if (clock) clock.innerText = new Date().toLocaleTimeString();
}

function login() {
    const user = document.getElementById('username').value.trim();
    if (user) {
        localStorage.setItem('blackbladeUser', user);
        document.getElementById('login-screen').style.display = 'none';
        document.getElementById('boot-screen').style.display = 'flex';
        setTimeout(() => {
            document.getElementById('boot-screen').style.display = 'none';
            document.getElementById('taskbar').style.display = 'flex';
        }, 1500);
    }
}

function autoLogin() {
    document.getElementById('login-screen').style.display = 'none';
    document.getElementById('boot-screen').style.display = 'flex';
    setTimeout(() => {
        document.getElementById('boot-screen').style.display = 'none';
        document.getElementById('taskbar').style.display = 'flex';
    }, 1500);
}

function launchApp(app) {
    fetch('apps/' + app + '.html')
        .then(res => res.text())
        .then(html => {
            const win = document.createElement('div');
            win.className = 'window';
            win.innerHTML = html;
            document.getElementById('desktop').appendChild(win);
        });
}
