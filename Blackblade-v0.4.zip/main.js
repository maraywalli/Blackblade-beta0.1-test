
window.onload = () => {
    setTimeout(() => {
        document.getElementById('boot-screen').style.display = 'none';
    }, 1500);
    updateClock();
    setInterval(updateClock, 1000);
};

function updateClock() {
    document.getElementById('clock').innerText = new Date().toLocaleTimeString();
}

function launchApp(app) {
    fetch('apps/' + app + '.html')
        .then(res => res.text())
        .then(html => {
            const win = document.createElement('div');
            win.className = 'window';
            win.innerHTML = html;
            document.getElementById('desktop').appendChild(win);
        });
}
