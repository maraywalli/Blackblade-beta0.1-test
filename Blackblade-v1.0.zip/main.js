
function startup() {
  console.log("Blackblade OS v1.0 started");
}
function openApp(app) {
  let windowEl = document.getElementById("window");
  windowEl.style.display = "block";
  if (app === "terminal") {
    windowEl.innerHTML = '<b>Blackblade Terminal</b><br><input id="term" onkeydown="handleCommand(event)" autofocus><div id="output"></div>';
  } else {
    fetch('apps/' + app + '.html').then(res => res.text()).then(html => windowEl.innerHTML = html);
  }
}
function handleCommand(e) {
  if (e.key === "Enter") {
    let val = e.target.value;
    document.getElementById("output").innerHTML += "<br>> " + val;
    if (val === "help") {
      document.getElementById("output").innerHTML += "<br>Available: help, date, clear, whoami, open browser, open files, echo [text]";
    } else if (val === "date") {
      document.getElementById("output").innerHTML += "<br>" + new Date().toString();
    } else if (val.startsWith("echo ")) {
      document.getElementById("output").innerHTML += "<br>" + val.slice(5);
    } else if (val === "whoami") {
      document.getElementById("output").innerHTML += "<br>guest@blackblade";
    } else if (val === "clear") {
      document.getElementById("output").innerHTML = "";
    } else if (val === "open browser") {
      openApp("browser");
    } else if (val === "open files") {
      openApp("files");
    } else {
      document.getElementById("output").innerHTML += "<br>Unknown command";
    }
    e.target.value = "";
  }
}
