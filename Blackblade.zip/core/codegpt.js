
export function initAI() {
  console.log("CodeGPT module loaded.");
}
