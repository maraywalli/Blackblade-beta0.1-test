
import { initTerminal } from './terminal.js';
import { initAI } from './codegpt.js';

window.onload = () => {
  initTerminal();
  initAI();
};
