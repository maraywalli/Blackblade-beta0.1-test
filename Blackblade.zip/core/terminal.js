
export function initTerminal() {
  const input = document.getElementById('terminal-input');
  const output = document.getElementById('terminal-output');
  input.addEventListener('keydown', (e) => {
    if (e.key === 'Enter') {
      const command = input.value.trim();
      input.value = '';
      output.innerHTML += `\n[user] ${command}`;
      handleCommand(command, output);
    }
  });
}

function handleCommand(cmd, output) {
  if (cmd === 'help') {
    output.innerHTML += "\n[AI] Available commands: help, run ai, clear";
  } else if (cmd === 'run ai') {
    output.innerHTML += "\n[AI] CodeGPT is ready. Type your question.";
  } else if (cmd === 'clear') {
    output.innerHTML = '';
  } else {
    output.innerHTML += `\n[AI] Unknown command: ${cmd}`;
  }
}
